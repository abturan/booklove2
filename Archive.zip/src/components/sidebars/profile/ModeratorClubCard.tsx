// src/components/sidebars/profile/ModeratorClubCard.tsx
import Image from 'next/image'
import Link from 'next/link'
type Counts = { memberships: number; picks: number; events: number }
export default function ModeratorClubCard({
  name, slug, bannerUrl, ownerName, ownerUsername, counts,
}:{
  name: string; slug: string; bannerUrl: string|null; ownerName: string; ownerUsername: string; counts: Counts
}) {
  return (
    <section className="rounded-3xl p-5 sm:p-6 bg-primary text-white shadow-soft">
      <div className="grid gap-4 lg:grid-cols-[1fr_auto]">
        <div className="flex items-start gap-4">
          
          <div className="min-w-0">
            <div className="text-2xl font-extrabold leading-tight break-words">{name}</div>
            <div className="mt-1 text-sm text-white/90 leading-tight">
              <div className="truncate">{ownerName}</div>
              {ownerUsername && <div className="truncate">@{ownerUsername}</div>}
            </div>
          </div>
        </div>

        <div className="flex lg:flex-col items-start gap-2 lg:self-start">
          <span className="px-2.5 py-1 rounded-full bg-white/15 text-white text-sm">👥 {counts.memberships} abone</span>
          <span className="px-2.5 py-1 rounded-full bg-white/15 text-white text-sm">📚 {counts.picks} seçki</span>
          <span className="px-2.5 py-1 rounded-full bg-white/15 text-white text-sm">🗓️ {counts.events} oturum</span>
          <div className="lg:col-span-2">
          <Link
            href={`/clubs/${slug}`}
            className="mt-4 inline-flex items-center justify-center gap-2 rounded-full bg-white text-primary px-4 py-2 text-sm font-medium hover:bg-white/90 transition whitespace-nowrap"
          >
            Klube git →
          </Link>
        </div>
        </div>

        
      </div>
    </section>
  )
}






