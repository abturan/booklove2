// src/components/sidebars/PublicProfileSidebar.tsx
import { prisma } from '@/lib/prisma'
import { auth } from '@/lib/auth'
import HeaderSection from '@/components/sidebars/profile/HeaderSection'
import FriendAction from '@/components/sidebars/profile/FriendAction'
import ModeratorClubCard from '@/components/sidebars/profile/ModeratorClubCard'
import ProfileTabs from '@/components/profile/ProfileTabs'

export default async function PublicProfileSidebar({ userId }: { userId: string }) {
  const session = await auth()
  const meId = session?.user?.id || null

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      username: true,
      avatarUrl: true,
      bio: true,
      Club: {
        select: {
          slug: true,
          name: true,
          bannerUrl: true,
          _count: { select: { memberships: true, picks: true, events: true } },
        },
      },
      Memberships: {
        include: {
          club: {
            select: {
              slug: true,
              name: true,
              bannerUrl: true,
              _count: { select: { memberships: true, picks: true, events: true } },
            },
          },
        },
        orderBy: { joinedAt: 'asc' },
      },
    },
  })
  if (!user) return null

  let mode: 'none' | 'message' | 'sent' | 'pending' | 'canSend' = 'none'
  if (meId && meId !== user.id) {
    const pairs = await prisma.friendRequest.findMany({
      where: { OR: [{ fromId: meId, toId: user.id }, { fromId: user.id, toId: meId }] },
      select: { fromId: true, toId: true, status: true, respondedAt: true },
      orderBy: { createdAt: 'desc' },
    })
    if (pairs.some((p) => p.status === 'ACCEPTED')) mode = 'message'
    else {
      const mine = pairs.find((p) => p.fromId === meId && p.toId === user.id)
      const theirs = pairs.find((p) => p.fromId === user.id && p.toId === meId)
      mode =
        mine?.status === 'PENDING'
          ? 'sent'
          : theirs?.status === 'PENDING' && !theirs.respondedAt
          ? 'pending'
          : 'canSend'
    }
  }

  const featured = user.Club ?? user.Memberships?.[0]?.club ?? null
  const hasMemberships = (user.Memberships?.length || 0) > 0

  return (
    <div className="space-y-5">
      <HeaderSection avatarUrl={user.avatarUrl} name={user.name} username={user.username}>
        <FriendAction mode={mode} userId={user.id} />
      </HeaderSection>

      {featured && (
        <ModeratorClubCard
          name={featured.name}
          slug={featured.slug}
          bannerUrl={featured.bannerUrl}
          ownerName={user.name || ''}
          ownerUsername={user.username || ''}
          counts={{
            memberships: featured._count?.memberships ?? 0,
            picks: featured._count?.picks ?? 0,
            events: featured._count?.events ?? 0,
          }}
        />
      )}

      <ProfileTabs
        userId={user.id}
        memberships={hasMemberships ? user.Memberships : []}
        bio={user.bio ?? ''}
      />
    </div>
  )
}
