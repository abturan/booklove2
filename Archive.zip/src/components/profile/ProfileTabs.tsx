// src/components/profile/ProfileTabs.tsx
'use client'

import { useMemo, useState } from 'react'
import clsx from 'clsx'

export type Tab = { value: string; label: string }

export default function ProfileTabs({
  tabs,
  defaultValue,
  render,
  className,
}: {
  tabs?: Tab[]
  defaultValue?: string
  render: (active: string) => React.ReactNode
  className?: string
}) {
  // Güvenli: tabs yoksa boş diziye düş
  const safeTabs = Array.isArray(tabs) ? tabs : []

  // Başlangıç aktif tab: defaultValue varsa onu, yoksa ilk tabın value'sunu seç
  const initial = useMemo(() => {
    if (defaultValue && safeTabs.some(t => t.value === defaultValue)) return defaultValue
    return safeTabs[0]?.value ?? ''
  }, [defaultValue, safeTabs])

  const [active, setActive] = useState(initial)

  // Tab listesi yoksa hiçbir şey gösterme (hata da atma)
  if (safeTabs.length === 0 || !active) return null

  return (
    <div className={clsx('w-full', className)}>
      <div className="w-full rounded-2xl bg-white/80 backdrop-blur p-1 ring-1 ring-black/5 shadow-sm grid grid-cols-4 gap-1">
        {safeTabs.map((t) => {
          const isActive = t.value === active
          return (
            <button
              key={t.value}
              type="button"
              onClick={() => setActive(t.value)}
              className={clsx(
                'h-10 rounded-xl text-sm font-semibold transition w-full',
                isActive ? 'bg-primary text-white shadow' : 'text-gray-700 hover:bg-gray-100'
              )}
              aria-pressed={isActive}
            >
              {t.label}
            </button>
          )
        })}
      </div>

      {/* Aktif tab içeriği */}
      <div>{render(active)}</div>
    </div>
  )
}
