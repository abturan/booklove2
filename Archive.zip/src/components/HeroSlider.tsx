// src/components/HeroSlider.tsx
'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import clsx from 'clsx'

const BRAND_RED = '#fa3c30'

// Başlıkları iki satır olacak şekilde \n ile bölüyoruz
const slides = [
  {
    id: 1,
    title: 'Yazar kürasyonlu\nkulüpler',
    subtitle: 'Katıl, keşfet, oku.',
    img: '/banners/banner1.png',
  },
  {
    id: 2,
    title: 'Dünyanın tüm okurları,\nbirleşin!',
    subtitle: 'Kulüpler, seçkiler, yeni kitaplar.',
    img: '/banners/banner2.png',
  },
  {
    id: 3,
    title: 'Boook.Love\nseni bekliyor',
    subtitle: 'Sohbet et, etkinliklere katıl, sosyalleş.',
    img: '/banners/banner3.png',
  },
]

export default function HeroSlider() {
  const [i, setI] = useState(0)
  const timer = useRef<NodeJS.Timeout | null>(null)
  const hostRef = useRef<HTMLDivElement | null>(null)

  // Otomatik kaydır
  useEffect(() => {
    timer.current = setInterval(() => setI((x) => (x + 1) % slides.length), 5000)
    return () => timer.current && clearInterval(timer.current)
  }, [])

  // Header’a “dock” sinyali (logo yumuşakça header’a geçsin)
  useEffect(() => {
    const el = hostRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        const e = entries[0]
        const dock = e.boundingClientRect.top <= 64 // header yüksekliği ~ 56–64px
        window.dispatchEvent(new CustomEvent('hero:dock', { detail: dock }))
      },
      { rootMargin: '-64px 0px 0px 0px', threshold: [0, 1] }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  function go(n: number) {
    setI((prev) => {
      const next = (prev + n + slides.length) % slides.length
      return next
    })
  }

  const s = slides[i]

  return (
    <div
      ref={hostRef}
      className="relative rounded-3xl overflow-hidden"
      style={{ background: BRAND_RED }}
    >
      {/* İç grid: solda logo+metin, sağda illüstrasyon */}
      <div className="relative container mx-auto px-8 lg:px-12 py-10 lg:py-12">
        <div className="grid grid-cols-12 items-center gap-6">
          {/* Sol: logo + başlıklar */}
          <div className="col-span-12 md:col-span-7 lg:col-span-7">
            <div className="flex items-start gap-6">
              <img
                src="/logo-fixed.svg"
                alt="boook.love"
                className="w-[112px] md:w-[128px] h-auto select-none"
                draggable={false}
              />
              <div className="text-white">
                <div className="text-xs tracking-[0.35em] opacity-85 mb-2">BOOOK.LOVE</div>
                <h1 className="leading-[0.98] font-semibold text-[40px] sm:text-[52px] lg:text-[64px]">
                  {s.title.split('\n').map((line, idx) => (
                    <span key={idx} className="block">{line}</span>
                  ))}
                </h1>
                <p className="mt-4 text-lg opacity-95">{s.subtitle}</p>
              </div>
            </div>
          </div>

          {/* Sağ: illüstrasyon  — görsel tabana dayalı, genişlik otomatik, yükseklik %100 */}
          <div className="col-span-12 md:col-span-5 lg:col-span-5 relative min-h-[180px] md:min-h-[220px] lg:min-h-[260px]">
            {/* Arka planı full kırmızı tutuyoruz; görsel taşıyıcı: */}
            <div className="absolute inset-0">
              <div className="absolute right-0 bottom-0 top-0 w-full">
                <Image
                  src={s.img}
                  alt=""
                  fill
                  priority
                  // fill + object-contain → yüksekliği doldur, genişliği doğal kalsın; sağa yasla.
                  className="object-contain object-right-bottom pointer-events-none select-none"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dots (sol-alt) */}
      <div className="absolute left-6 bottom-4 flex items-center gap-2">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            aria-label={`Slide ${idx + 1}`}
            className={clsx(
              'h-2 rounded-full transition-all',
              idx === i ? 'w-8 bg-white' : 'w-3 bg-white/70 hover:bg-white/90'
            )}
          />
        ))}
      </div>

      {/* Oklar (sağ-alt) */}
      <div className="absolute right-6 bottom-4 flex items-center gap-2">
        <button
          onClick={() => go(-1)}
          aria-label="Önceki"
          className="h-9 w-9 rounded-full bg-white text-gray-900 grid place-content-center shadow hover:scale-[1.03] transition"
        >
          ‹
        </button>
        <button
          onClick={() => go(+1)}
          aria-label="Sonraki"
          className="h-9 w-9 rounded-full bg-white text-gray-900 grid place-content-center shadow hover:scale-[1.03] transition"
        >
          ›
        </button>
      </div>
    </div>
  )
}
