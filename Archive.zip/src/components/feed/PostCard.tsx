// src/components/feed/PostCard.tsx
export { default } from './post/PostCard'
export type { Post } from './post/types'