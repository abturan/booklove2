declare module 'pdfkit/js/pdfkit.standalone.js' {
  const PDFDocument: any
  export default PDFDocument
}