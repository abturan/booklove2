// src/app/u/[username]/page.tsx
import { prisma } from '@/lib/prisma'
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import PublicProfileSidebar from '@/components/sidebars/PublicProfileSidebar'
import InfiniteFeed from '@/components/feed/InfiniteFeed'
import ProfileBanner from '@/components/profile/ProfileBanner'
import ProfileAboutCard from '@/components/profile/ProfileAboutCard'

type Props = { params: { username: string } }
export const dynamic = 'force-dynamic'

function sanitizeHandle(s: string) {
  try { return decodeURIComponent((s || '').replace(/^@+/, '')).trim() } catch { return (s || '').replace(/^@+/, '').trim() }
}
function deslug(s: string) {
  return (s || '').replace(/-/g, ' ').trim()
}
function normalizeTR(s: string) {
  return (s || '')
    .replace(/ç/gi, 'c')
    .replace(/ğ/gi, 'g')
    .replace(/[ıİ]/g, 'i')
    .replace(/ö/gi, 'o')
    .replace(/ş/gi, 's')
    .replace(/ü/gi, 'u')
    .trim()
}
function variants(raw: string) {
  const base = deslug(raw)
  const a = normalizeTR(base)
  const b = base.replace(/ı/g, 'i').replace(/i/g, 'ı')
  return Array.from(new Set([base, a, b])).filter(Boolean)
}

export default async function PublicProfilePage({ params }: Props) {
  const session = await auth()
  const viewerId = session?.user?.id || null
  const handle = sanitizeHandle(params.username)

  let user =
    (await prisma.user.findFirst({
      where: { OR: [{ username: handle }, { slug: handle }] },
      select: { id: true, name: true, username: true, slug: true, bio: true, avatarUrl: true, bannerUrl: true },
    })) || null

  if (!user) {
    const tries = variants(handle)
    for (const v of tries) {
      const exact = await prisma.user.findFirst({
        where: { name: { equals: v, mode: 'insensitive' } },
        select: { id: true, name: true, username: true, slug: true, bio: true, avatarUrl: true, bannerUrl: true },
      })
      if (exact) { user = exact; break }
      const partial = await prisma.user.findFirst({
        where: { name: { contains: v, mode: 'insensitive' } },
        select: { id: true, name: true, username: true, slug: true, bio: true, avatarUrl: true, bannerUrl: true },
      })
      if (partial) { user = partial; break }
    }
  }

  if (!user) {
    return (
      <div className="space-y-6">
        <ProfileBanner src={null} canEdit={false} />
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="card p-5">Profil bulunamadı.</div>
          <div className="lg:col-span-2 space-y-6">
            <ProfileAboutCard bio="Bu profil henüz boş." />
          </div>
        </div>
      </div>
    )
  }

  const canonical = user.username || user.slug || ''
  if (canonical && handle !== canonical) {
    redirect(`/u/${canonical}`)
  }

  const canEdit = viewerId === user.id

  return (
    <div className="space-y-6">
      <ProfileBanner src={user.bannerUrl} canEdit={!!canEdit} />
      <div className="grid lg:grid-cols-3 gap-6">
        <div>
          <PublicProfileSidebar userId={user.id} />
        </div>
        <div className="lg:col-span-2 space-y-6">
          <ProfileAboutCard bio={user.bio ?? ''} />
          <InfiniteFeed scope={`user:${user.username || user.slug || user.name}`} />
        </div>
      </div>
    </div>
  )
}






