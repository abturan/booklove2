export default function Page(){ return <div>register-ok</div> }
