// src/app/@modals/default.tsx
export default function DefaultModalSlot() {
  return null
}
