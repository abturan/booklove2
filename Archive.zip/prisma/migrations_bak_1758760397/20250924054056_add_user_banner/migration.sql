-- AlterTable
ALTER TABLE "public"."User" ADD COLUMN     "bannerUrl" TEXT;
