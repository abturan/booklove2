-- AlterTable
ALTER TABLE "public"."Club" ADD COLUMN     "capacity" INTEGER;
