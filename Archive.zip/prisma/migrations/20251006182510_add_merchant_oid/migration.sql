-- DropIndex
DROP INDEX "public"."PaymentIntent_merchantOid_idx";
